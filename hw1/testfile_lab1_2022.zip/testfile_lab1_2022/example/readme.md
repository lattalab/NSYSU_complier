[使用說明]

> make all            (編譯出執行檔)
> ./a.out < test.in   (執行)
> make clean          (清除檔案)